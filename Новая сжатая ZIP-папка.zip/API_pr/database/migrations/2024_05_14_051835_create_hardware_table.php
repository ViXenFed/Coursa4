<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('motherboards', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
            $table->text('image-URL');
            $table->string('brand', 60);
            $table->string('socket', 60);
            $table->string('RAM_type', 60);
            $table->integer('RAM_num');
            $table->string('TDP_max', 60);
            $table->integer('SATA_num');
            $table->integer('M2_num');
            $table->integer('PCI_num');
        });
        Schema::create('processors', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
            $table->text('image-URL');
            $table->string('brand', 60);
            $table->string('socket', 60);
            $table->integer('Kernel_num');
            $table->float('Base_HHz');
            $table->float('Max_HHz');
            $table->string('Cache', 60);
            $table->string('TDP_max', 60);
        });
        Schema::create('RAM', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
            $table->text('image-URL');
            $table->string('brand', 60);
            $table->string('Memory', 60);
            $table->string('type', 60);
            $table->string('Freq_HHz', 60);
        });
        Schema::create('ROM', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
            $table->text('image-URL');
            $table->string('brand', 60);
            $table->string('type', 60);
            $table->string('Memory', 60);
            $table->string('Input_type', 60);
        });
        Schema::create('Videocards', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
            $table->text('image-URL');
            $table->string('brand', 60);
            $table->integer('Min_PowerBlock');
            $table->boolean('Support_SLI');
            $table->boolean('Support_Crossfire');
        });
        Schema::create('PowerBlock', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
            $table->text('image-URL');
            $table->string('brand', 60);
            $table->integer('Power');
            $table->string('Rate', 60);
        });
        Schema::create('Brands', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('Motherboards');
        Schema::dropIfExists('processors');
        Schema::dropIfExists('RAM');
        Schema::dropIfExists('ROM');
        Schema::dropIfExists('Videocards');
        Schema::dropIfExists('PowerBlock');
        Schema::dropIfExists('Brands');
    }
};
