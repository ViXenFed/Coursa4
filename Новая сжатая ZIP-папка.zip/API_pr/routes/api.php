<?php

use App\Http\Controllers\hardwareController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// получть
Route::get('/motherboard', [hardwareController::class, 'show_motherboard']);
Route::get('/processors', [hardwareController::class, 'show_processors']);
Route::get('/ram', [hardwareController::class, 'show_ram']);
Route::get('/rom', [hardwareController::class, 'show_ROM']);
Route::get('/videocards', [hardwareController::class, 'show_videocards']);
Route::get('/power', [hardwareController::class, 'show_powerblocks']);
Route::get('/brands', [hardwareController::class, 'show_brands']);

// поиск
Route::get('/{cat}/?q={q}', [hardwareController::class, 'search']);